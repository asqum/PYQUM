# Pulse generator
A python package to generate pulse operating on Qubit 